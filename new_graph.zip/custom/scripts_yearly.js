
	$(document).ready(function() {	
		$("#allYear").click(function(){
			$('.demo-container').show();
	/*	var urlList = "http://172.29.129.235:5000/944";
		$.ajax({
			url : urlList,
			dataType : 'json',
			type : 'GET',
			    contentType: 'application/json',
			success : function(data1) {
				alert(data1);
			},
			error: function(xhr, status, error) {
				alert(error.httpRequest);
			}
		}); 
		*/
		var data = [
						{
							"plot_points":[
									25.36568257457039,
									285154
								],
							"year" : 2012,	
							"y_axis": "Number of Members",
							"line_id": "944",
							"range_x": [
								25.36568257457039,
								25.36568257457039
							],
							"timeframe": "yearly",
							"range_y": [
								285154,
								285154
							],
							"x_axis": "Avg. Returning Gap"
						},
						{
							"plot_points":[
									28.367231722386997,
									410707
								],
							"year" : 2013,	
							"y_axis": "Number of Members",
							"line_id": "944",
							"range_x": [
								28.367231722386997,
								28.367231722386997
							],
							"timeframe": "yearly",
							"range_y": [
								410707,
								410707
							],
							"x_axis": "Avg. Returning Gap"
						},
						{
							"plot_points":[
									29.73752805713466,
									475179
								],
							"year" : 2014,	
							"y_axis": "Number of Members",
							"line_id": "944",
							"range_x": [
								29.73752805713466,
								29.73752805713466
							],
							"timeframe": "yearly",
							"range_y": [
								475179,
								475179
							],
							"x_axis": "Avg. Returning Gap"
						},
						{
							"plot_points":[
									29.298527417716688,
									449867
								],
							"year" : 2015,	
							"y_axis": "Number of Members",
							"line_id": "944",
							"range_x": [
								29.298527417716688,
								29.298527417716688
							],
							"timeframe": "yearly",
							"range_y": [
								449867,
								449867
							],
							"x_axis": "Avg. Returning Gap"
						},
						{
							"plot_points": [
									11.14520551501609,
									126438,
								],
							"year" : 2016, 	
							"y_axis": "Number of Members",
							"line_id": "944",
							"range_x": [
								11.14520551501609,
								11.14520551501609
							],
							"timeframe": "yearly",
							"range_y": [
								126438,
								126438
							],
							"x_axis": "Avg. Returning Gap"
						}
					];
				
				var dataSet=[];	
				$.each(data, function(index, value) {
					dataSet.push(data[index].plot_points);
				});
				
			var plot = $.plot("#placeholder", [
				{ data: dataSet, label: "Members Gap" }
			], {
				series: {
					lines: {
						show: true
					},
					points: {
						show: true
					}
				},
				grid: {
					hoverable: true,
					clickable: true
				},
				xaxis : {
					min : 0,
					max : 30,
					axisLabel : data[0].x_axis,
					axisLabelUseCanvas : false,
					axisLabelFontSizePixels: 12,
					axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
					axisLabelPadding: 5
				},
				yaxis:{
					min : 0,
					max : 600000,
					axisLabel: data[0].y_axis,
					axisLabelUseCanvas: false,
					axisLabelFontSizePixels: 12,
					axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
					axisLabelPadding: 5
				}
			});

			function showTooltip(x, y, contents) {
				$("<div id='tooltip'>" + contents + "</div>").css({
					position: "absolute",
					display: "none",
					top: y + 5,
					left: x + 5,
					border: "1px solid #fdd",
					padding: "5px",
					color: "#222",
					cursor: "pointer",
					"background-color": "#fee",
					opacity: 0.90
				}).appendTo("body").fadeIn(200);
			}
	 
			var previousPoint = null;
			$("#placeholder").bind("plothover", function (event, pos, item) {
			/*	$.each(data, function(index, value) {
					item.datapoint[index].push(data[index].year);
				});
			*/	
				if (item) {
					if (previousPoint != item.dataIndex) {
						previousPoint = item.dataIndex;
						$("#tooltip").remove();
						var x = item.datapoint[0].toFixed(2),
						y = parseInt(item.datapoint[1].toFixed(2)),
						z = data[item.dataIndex].year;
						//item.series.label
						showTooltip(
							item.pageX, 
							item.pageY,
							"<h6>" + x + " " + "days" + "</h6>" + "<h6>" + y + " " + "Members" + "</h6>" + "<h6>" + " " + "year" + " " + z + "</h6>");
					}
				} else {
					$("#tooltip").remove();
					previousPoint = null;            
				}
			});
		});	
	});