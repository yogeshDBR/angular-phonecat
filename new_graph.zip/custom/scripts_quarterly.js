
	$(document).ready(function() {	
		$("#yearID").change(function(){
		$('.demo-container').show();
		/*	var urlList = "http://172.29.129.235:5000/944/quarterly/2014";
			$.ajax({
				url : urlList,
				dataType : 'jsonp',
				type : 'GET',
				success : function(data1) {
					alert(data1);
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
				}
			}); 
		*/
			 var data = [{
						"x_axis": "Avg. Returning Gap",
						"timeframe": "quarterly",
						"line_id": "944",
						"range_x": [6.4744446768086386, 7.497232505200775],
						"range_y": [61491.0, 128234.0],
						"plot_points": [
							[6.4744446768086386, 73511.0],
							[7.0557955045807494, 70963.0],
							[6.733915744066578, 61491.0],
							[7.497232505200775, 128234.0]
						],
						"y_axis": "Number of Members",
						"year": "2014"
					}];
		/*	function someFunc(ctx, x, y, radius, shadow) 
			{
			   someFunc.calls++;
			   if (someFunc.calls * 2 == 0)
			   {
					ctx.arc(x, y, radius * 2, 0, shadow ? Math.PI : Math.PI * 4, false);
			   }
			   else 
			   {
				   ctx.arc(x, y, radius, 0, shadow ? Math.PI : Math.PI * 4, false);
			   }
			};
			someFunc.calls = 0;
		*/	
			var plot = $.plot("#placeholder", [
				{ data: data[0].plot_points, label: data[0].timeframe + " " + data[0].year }
			], {
				series: {
					lines: {
						show: false
					},
					points: {
						show: true,
					//	symbol: someFunc
					radius : 4
					}
				},
				grid: {
					hoverable: true,
					clickable: true
				},
				xaxis : {
					min : data[0].range_x[0] - 0.2,
					max : data[0].range_x[1] + 0.2,
					axisLabel : data[0].x_axis,
					axisLabelUseCanvas : false,
					axisLabelFontSizePixels: 12,
					axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
					axisLabelPadding: 5
				},
				yaxis:{
					min : data[0].range_y[0]-10000,
					max : data[0].range_y[1]+20000,
					axisLabel: data[0].y_axis,
					axisLabelUseCanvas: false,
					axisLabelFontSizePixels: 12,
					axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
					axisLabelPadding: 5
				}
			});

			function showTooltip(x, y, contents) {
				$("<div id='tooltip'>" + contents + "</div>").css({
					position: "absolute",
					display: "none",
					top: y + 5,
					left: x + 5,
					border: "1px solid #fdd",
					padding: "5px",
					color: "#222",
					cursor: "pointer",
					"background-color": "#fee",
					opacity: 0.90
				}).appendTo("body").fadeIn(200);
			}
	 
			var previousPoint = null;
			$("#placeholder").bind("plothover", function (event, pos, item) {
			/*	$.each(data, function(index, value) {
					item.datapoint[index].push(data[index].year);
				});
			*/	
				if (item) {
					if (previousPoint != item.dataIndex) {
						previousPoint = item.dataIndex;
						$("#tooltip").remove();
						var x = item.datapoint[0].toFixed(2),
						y = parseInt(item.datapoint[1].toFixed(2));
						z = item.dataIndex +1;
						//item.series.label
						showTooltip(
							item.pageX, 
							item.pageY,
							"<h6>" + z + " Quarter " + "</h6>" +"<h6>" + x + " " + "days" + "</h6>" + "<h6>" + y + " " + "Members" + "</h6>" + "<h6>");
					}
				} else {
					$("#tooltip").remove();
					previousPoint = null;            
				}
			});	
		});	
	});